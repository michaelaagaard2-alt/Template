import QtQuick
import QtQuick.Controls
import org.qfield
import Theme

Item {

  property string importedProjectsRoot: {
    if (typeof qgisProject === "undefined" || qgisProject.homePath === "")
      return ""
    let p = qgisProject.homePath.replace(/\/+$/, "")
    let parts = p.split("/")
    parts.pop()
    return parts.join("/")
  }

  property string templateFolder:  importedProjectsRoot + "/Template"
  property string templateProject: templateFolder + "/Template.qgs"

  QfToolButton {
    id: newSurveyButton
    iconSource: Theme.getThemeVectorIcon("ic_add_black_24dp")
    iconColor: Theme.toolButtonColor
    bgcolor: Theme.toolButtonBackgroundColor
    round: true

    onClicked: {
      // DEBUG: show the paths we are computing
      iface.mainWindow().displayToast(
        "homePath: " + qgisProject.homePath
        + " | root: " + importedProjectsRoot
        + " | template: " + templateFolder
        + " | exists: " + FileUtils.fileExists(templateFolder)
      )
    }
  }

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(newSurveyButton)
  }
}
