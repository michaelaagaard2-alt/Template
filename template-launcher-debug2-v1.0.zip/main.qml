import QtQuick
import QtQuick.Controls
import org.qfield
import Theme

Item {

  property string importedProjectsRoot: {
    if (typeof qgisProject === "undefined" || qgisProject.homePath === "")
      return ""
    let p = qgisProject.homePath.replace(/\/+$/, "")
    let idx = p.indexOf("/files/")
    if (idx === -1) return ""
    return p.substring(0, idx) + "/files/Imported Projects"
  }

  property string templateFolder:  importedProjectsRoot + "/Template"
  property string templateProject: templateFolder + "/Template.qgs"

  QfToolButton {
    id: newSurveyButton
    iconSource: Theme.getThemeVectorIcon("ic_add_black_24dp")
    iconColor: Theme.toolButtonColor
    bgcolor: Theme.toolButtonBackgroundColor
    round: true

    onClicked: {
      iface.mainWindow().displayToast(
        "RAW homePath: [" + qgisProject.homePath + "]"
        + " | idx of /files/: " + qgisProject.homePath.indexOf("/files/")
        + " | computed root: [" + importedProjectsRoot + "]"
        + " | templateFolder exists: " + FileUtils.fileExists(templateFolder)
      )
    }
  }

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(newSurveyButton)
  }
}
