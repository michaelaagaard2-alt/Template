import QtQuick
import QtQuick.Controls
import org.qfield
import Theme

Item {

  // Find the QField "files" root by locating "/files/" in homePath,
  // then always append "Imported Projects" — regardless of whether the
  // current project lives in Created Projects, Imported Projects, etc.
  property string importedProjectsRoot: {
    if (typeof qgisProject === "undefined" || qgisProject.homePath === "")
      return ""
    let p = qgisProject.homePath.replace(/\/+$/, "")
    let idx = p.indexOf("/files/")
    if (idx === -1) return ""
    return p.substring(0, idx) + "/files/Imported Projects"
  }

  property string templateFolder:  importedProjectsRoot + "/Template"
  property string templateProject: templateFolder + "/Template.qgs"

  // ── Toolbar button ──────────────────────────────────────────────────────────
  QfToolButton {
    id: newSurveyButton
    iconSource: Theme.getThemeVectorIcon("ic_add_black_24dp")
    iconColor: Theme.toolButtonColor
    bgcolor: Theme.toolButtonBackgroundColor
    round: true

    onClicked: {
      if (importedProjectsRoot === "") {
        iface.mainWindow().displayToast("Open any project first so the plugin can locate the Imported Projects folder.")
        return
      }
      if (!FileUtils.fileExists(templateFolder)) {
        iface.mainWindow().displayToast("No 'Template' folder found in Imported Projects.")
        return
      }
      if (!FileUtils.fileExists(templateProject)) {
        iface.mainWindow().displayToast("No 'Template.qgs' found inside the Template folder.")
        return
      }
      namingDialog.open()
    }
  }

  // ── Naming dialog ───────────────────────────────────────────────────────────
  QfDialog {
    id: namingDialog
    parent: iface.mainWindow().contentItem
    width: Math.min(400, iface.mainWindow().width - 48)
    height: 220
    x: (iface.mainWindow().width  - width)  / 2
    y: (iface.mainWindow().height - height) / 2
    title: "New Inspection Project"

    Column {
      width: parent.width
      spacing: 12

      Text {
        width: parent.width
        text: "Enter a name for the new project folder:"
        color: Theme.mainTextColor
        font.pixelSize: 14
        wrapMode: Text.WordWrap
      }

      TextField {
        id: projectNameField
        width: parent.width
        placeholderText: "e.g. Site_A_2026-05-28"
        font.pixelSize: 14
        onVisibleChanged: if (visible) text = ""
      }
    }

    onAccepted: {
      let rawName = projectNameField.text.trim()

      if (rawName === "") {
        iface.mainWindow().displayToast("Please enter a project name.")
        namingDialog.open()
        return
      }

      let safeName = FileUtils.sanitizeFilePathPart(rawName)
      let destPath = importedProjectsRoot + "/" + safeName

      if (FileUtils.fileExists(destPath)) {
        iface.mainWindow().displayToast("A folder named '" + safeName + "' already exists. Choose a different name.")
        namingDialog.open()
        return
      }

      let ok = false
      try {
        ok = FileUtils.copyRecursively(templateFolder, destPath)
      } catch (e) {
        iface.mainWindow().displayToast("copyRecursively not available in this build — please report this.")
        return
      }

      if (!ok) {
        iface.mainWindow().displayToast("Failed to copy template. Check the Template folder is valid.")
        return
      }

      iface.loadFile(destPath + "/Template.qgs")
      iface.mainWindow().displayToast("Opened: " + safeName)
    }
  }

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(newSurveyButton)
  }
}
